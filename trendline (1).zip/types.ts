
export type PostType = 'photo' | 'video' | 'document';

export interface Post {
  id: string;
  type: PostType;
  title: string;
  description: string;
  contentUrl: string; // Base64 or URL
  fileName?: string;
  category: 'News' | 'Projects' | 'Home';
  author: string;
  createdAt: string;
}

export interface User {
  id: string;
  name: string;
  username: string;
  password: string;
  role: 'admin';
}
