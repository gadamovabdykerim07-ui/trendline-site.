
import React from 'react';
import { Post } from '../types';
import { PostCard } from '../components/PostCard';

interface ProjectsProps {
  posts: Post[];
}

export const Projects: React.FC<ProjectsProps> = ({ posts }) => {
  const projectPosts = posts.filter(p => p.category === 'Projects').reverse();

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      <div className="mb-12">
        <h1 className="text-4xl md:text-5xl font-black text-slate-900 mb-4">Our Projects</h1>
        <p className="text-xl text-slate-500 max-w-2xl">
          Showcasing the vision and execution of Trendline through visual media and detailed reports.
        </p>
      </div>

      {projectPosts.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projectPosts.map(post => (
            <PostCard key={post.id} post={post} />
          ))}
        </div>
      ) : (
        <div className="bg-slate-50 rounded-3xl p-20 text-center border-2 border-dashed border-slate-200">
          <p className="text-slate-400 font-medium italic">Portfolio items are currently being curated.</p>
        </div>
      )}
    </div>
  );
};
