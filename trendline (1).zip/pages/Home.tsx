
import React from 'react';
import { Post } from '../types';
import { PostCard } from '../components/PostCard';
import { ArrowRight, TrendingUp, Users, ShieldCheck } from 'lucide-react';
import { Link } from 'react-router-dom';

interface HomeProps {
  posts: Post[];
}

export const Home: React.FC<HomeProps> = ({ posts }) => {
  const homePosts = posts.filter(p => p.category === 'Home').slice(0, 3);
  const latestPosts = posts.slice(-4).reverse();

  return (
    <div className="space-y-20 pb-20">
      {/* Hero Section */}
      <section className="relative h-[80vh] flex items-center bg-slate-900 overflow-hidden">
        <div className="absolute inset-0">
          <img 
            src="https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=2015" 
            className="w-full h-full object-cover opacity-30"
            alt="Business Background"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-slate-900 via-slate-900/80 to-transparent" />
        </div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-white z-10">
          <div className="max-w-2xl">
            <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight mb-6">
              Defining the <span className="text-blue-400">Future</span> of Modern Trends.
            </h1>
            <p className="text-xl text-slate-300 mb-10 leading-relaxed">
              Trendline is a dynamic collaboration of Gadamov Abdykerim, Sartbayev Said, and Muhammad Iskhok Abdujalilov. We build, analyze, and innovate.
            </p>
            <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-6">
              <Link to="/projects" className="bg-white text-slate-900 px-8 py-4 rounded-full font-bold text-lg hover:bg-slate-100 transition-all flex items-center justify-center space-x-2">
                <span>View Projects</span>
                <ArrowRight size={20} />
              </Link>
              <Link to="/about" className="border border-white/30 backdrop-blur text-white px-8 py-4 rounded-full font-bold text-lg hover:bg-white/10 transition-all text-center">
                Our Team
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Stats/Features */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm text-center space-y-4">
            <div className="bg-blue-50 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto text-blue-600">
              <TrendingUp size={32} />
            </div>
            <h3 className="text-xl font-bold text-slate-900">High Growth</h3>
            <p className="text-slate-500 leading-relaxed">Continuous improvement and scaling in all our operations and client projects.</p>
          </div>
          <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm text-center space-y-4">
            <div className="bg-purple-50 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto text-purple-600">
              <Users size={32} />
            </div>
            <h3 className="text-xl font-bold text-slate-900">Expert Team</h3>
            <p className="text-slate-500 leading-relaxed">Led by industry professionals with unique skillsets in development and management.</p>
          </div>
          <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm text-center space-y-4">
            <div className="bg-emerald-50 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto text-emerald-600">
              <ShieldCheck size={32} />
            </div>
            <h3 className="text-xl font-bold text-slate-900">Secure & Robust</h3>
            <p className="text-slate-500 leading-relaxed">Our document handling and project execution focus on integrity and quality.</p>
          </div>
        </div>
      </section>

      {/* Featured Content */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 space-y-4 md:space-y-0">
          <div>
            <h2 className="text-3xl md:text-4xl font-black text-slate-900 mb-2">Recent Highlights</h2>
            <p className="text-slate-500">Explore the latest updates and announcements from our team.</p>
          </div>
          <Link to="/news" className="text-blue-600 font-bold flex items-center space-x-1 hover:space-x-2 transition-all">
            <span>See all updates</span>
            <ArrowRight size={18} />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {latestPosts.map(post => (
            <PostCard key={post.id} post={post} />
          ))}
        </div>
      </section>
    </div>
  );
};
