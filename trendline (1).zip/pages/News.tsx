
import React from 'react';
import { Post } from '../types';
import { PostCard } from '../components/PostCard';

interface NewsProps {
  posts: Post[];
}

export const News: React.FC<NewsProps> = ({ posts }) => {
  const newsPosts = posts.filter(p => p.category === 'News').reverse();

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      <div className="mb-12">
        <h1 className="text-4xl md:text-5xl font-black text-slate-900 mb-4">Latest News</h1>
        <p className="text-xl text-slate-500 max-w-2xl">
          Stay up to date with the latest documents, announcements, and insights from the Trendline team.
        </p>
      </div>

      {newsPosts.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {newsPosts.map(post => (
            <PostCard key={post.id} post={post} />
          ))}
        </div>
      ) : (
        <div className="bg-slate-50 rounded-3xl p-20 text-center border-2 border-dashed border-slate-200">
          <p className="text-slate-400 font-medium italic">No news articles published yet.</p>
        </div>
      )}
    </div>
  );
};
