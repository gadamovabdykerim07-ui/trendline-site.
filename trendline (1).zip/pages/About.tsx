
import React from 'react';
import { ADMIN_USERS } from '../constants';
import { Mail, Briefcase, Award } from 'lucide-react';

export const About: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 space-y-20">
      <section className="text-center space-y-6 max-w-3xl mx-auto">
        <h1 className="text-4xl md:text-5xl font-black text-slate-900">About Trendline</h1>
        <p className="text-xl text-slate-500 leading-relaxed">
          Trendline is more than a platform; it's a testament to the collaborative power of three individuals committed to excellence. Our mission is to document our journey and showcase our capabilities to the world.
        </p>
      </section>

      <section className="grid grid-cols-1 md:grid-cols-3 gap-12">
        {ADMIN_USERS.map((user, idx) => (
          <div key={user.id} className="group flex flex-col items-center">
            <div className="relative mb-8">
              <div className="w-48 h-48 rounded-full overflow-hidden border-4 border-slate-100 group-hover:border-blue-500 transition-all duration-300">
                <img 
                  src={`https://picsum.photos/seed/${user.username}/300/300`} 
                  alt={user.name}
                  className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all"
                />
              </div>
              <div className="absolute -bottom-2 right-4 bg-slate-900 text-white p-2 rounded-xl text-xs font-bold uppercase">
                {idx === 0 ? 'Lead Admin' : 'Co-Founder'}
              </div>
            </div>
            
            <h3 className="text-2xl font-bold text-slate-900 mb-1">{user.name}</h3>
            <p className="text-slate-500 text-sm mb-6 uppercase tracking-widest">{user.username}</p>
            
            <div className="space-y-4 w-full">
               <div className="flex items-start space-x-3 p-4 bg-white rounded-2xl border border-slate-100">
                 <Briefcase size={20} className="text-blue-500 shrink-0 mt-1" />
                 <div>
                   <h4 className="font-bold text-slate-900 text-sm">Strategic Development</h4>
                   <p className="text-xs text-slate-500">Overseeing major platform transitions and project architecture.</p>
                 </div>
               </div>
               <div className="flex items-start space-x-3 p-4 bg-white rounded-2xl border border-slate-100">
                 <Award size={20} className="text-emerald-500 shrink-0 mt-1" />
                 <div>
                   <h4 className="font-bold text-slate-900 text-sm">Trend Analysis</h4>
                   <p className="text-xs text-slate-500">Documenting and predicting market shifts for Trendline's future.</p>
                 </div>
               </div>
            </div>
          </div>
        ))}
      </section>

      <section className="bg-slate-900 rounded-[3rem] p-12 md:p-20 text-white relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-blue-500/20 blur-[120px] rounded-full" />
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-purple-500/20 blur-[120px] rounded-full" />
        
        <div className="relative z-10 grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-4xl font-black mb-6">Our Shared Vision</h2>
            <p className="text-slate-400 text-lg leading-relaxed mb-8">
              We believe in the power of shared expertise. By combining our backgrounds, we create a robust framework for documenting progress and delivering high-quality visual content.
            </p>
            <div className="flex items-center space-x-4">
              <div className="flex -space-x-3">
                {ADMIN_USERS.map(u => (
                  <img key={u.id} src={`https://picsum.photos/seed/${u.username}/50/50`} className="w-10 h-10 rounded-full border-2 border-slate-900" alt="" />
                ))}
              </div>
              <span className="text-slate-400 text-sm">United for excellence.</span>
            </div>
          </div>
          <div className="bg-white/5 backdrop-blur-sm border border-white/10 p-8 rounded-3xl space-y-6">
            <h3 className="text-xl font-bold flex items-center space-x-2">
              <Mail className="text-blue-400" />
              <span>Contact Us</span>
            </h3>
            <p className="text-slate-300">
              For inquiries regarding projects, partnerships, or trend reports, reach out to our team admins.
            </p>
            <button className="w-full bg-white text-slate-900 py-4 rounded-2xl font-bold hover:bg-slate-100 transition-all">
              Send Message
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
