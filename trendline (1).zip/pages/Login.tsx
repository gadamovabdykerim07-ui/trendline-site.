
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ADMIN_USERS, Logo } from '../constants';
import { Lock, User as UserIcon, AlertCircle } from 'lucide-react';

interface LoginProps {
  onLogin: (user: any) => void;
}

export const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const user = ADMIN_USERS.find(
      (u) => u.username === username && u.password === password
    );

    if (user) {
      onLogin(user);
      navigate('/admin');
    } else {
      setError('Invalid username or password. Check your admin credentials.');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 px-4">
      <div className="max-w-md w-full">
        <div className="text-center mb-10">
          <div className="inline-block bg-white p-4 rounded-3xl shadow-sm mb-6 border border-slate-100">
            <Logo className="h-12 w-auto" />
          </div>
          <h2 className="text-3xl font-black text-slate-900">Admin Login</h2>
          <p className="mt-2 text-slate-500">Restricted access for Trendline admins.</p>
        </div>

        <form onSubmit={handleLogin} className="bg-white p-10 rounded-3xl shadow-xl shadow-slate-200/50 border border-slate-100 space-y-6">
          {error && (
            <div className="bg-red-50 text-red-600 p-4 rounded-2xl flex items-center space-x-3 text-sm font-medium border border-red-100">
              <AlertCircle size={18} className="shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div className="space-y-2">
            <label className="block text-sm font-bold text-slate-700">Username</label>
            <div className="relative">
              <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input
                type="text"
                required
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-2xl py-4 pl-12 pr-4 focus:ring-2 focus:ring-slate-900 focus:bg-white outline-none transition-all font-medium"
                placeholder="Enter admin username"
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-bold text-slate-700">Password</label>
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-2xl py-4 pl-12 pr-4 focus:ring-2 focus:ring-slate-900 focus:bg-white outline-none transition-all font-medium"
                placeholder="••••"
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full bg-slate-900 text-white py-5 rounded-2xl font-bold text-lg hover:bg-slate-800 active:scale-[0.98] transition-all shadow-lg shadow-slate-900/10"
          >
            Authenticate Access
          </button>
        </form>
        
        <p className="mt-8 text-center text-slate-400 text-sm">
          Forgot credentials? Contact Gadamov Abdykerim.
        </p>
      </div>
    </div>
  );
};
