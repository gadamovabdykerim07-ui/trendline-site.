
import React from 'react';
import { Post, User } from './types';

export const SITE_NAME = 'Trendline';
export const INSTAGRAM_URL = 'https://www.instagram.com/trend_line_us/';
export const CREATED_BY = 'Gadamov Abdykerim';

export const ADMIN_USERS: User[] = [
  {
    id: '1',
    name: 'Gadamov Abdykerim',
    username: 'gadamovabdykerim07',
    password: '8778',
    role: 'admin',
  },
  {
    id: '2',
    name: 'Sartbayev Said',
    username: 'sartbayev_said',
    password: '6767',
    role: 'admin',
  },
  {
    id: '3',
    name: 'Muhammad Iskhok Abdujalilov',
    username: 'muhammad_iskhok',
    password: '1031',
    role: 'admin',
  },
];

export const INITIAL_POSTS: Post[] = [
  {
    id: 'p1',
    type: 'photo',
    title: 'Welcome to Trendline',
    description: 'We are excited to launch our new digital platform.',
    contentUrl: 'https://picsum.photos/seed/trend1/1200/600',
    category: 'Home',
    author: 'Gadamov Abdykerim',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'p2',
    type: 'video',
    title: 'Project Alpha Showcase',
    description: 'A brief look at our latest architectural project.',
    contentUrl: 'https://www.w3schools.com/html/mov_bbb.mp4',
    category: 'Projects',
    author: 'Sartbayev Said',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'p3',
    type: 'document',
    title: 'Quarterly Report Q4',
    description: 'Comprehensive analysis of our growth this year.',
    contentUrl: '#',
    fileName: 'report_q4.pdf',
    category: 'News',
    author: 'Muhammad Iskhok Abdujalilov',
    createdAt: new Date().toISOString(),
  }
];

export const Logo = ({ className = "h-12" }: { className?: string }) => (
  <svg viewBox="0 0 400 200" className={className} xmlns="http://www.w3.org/2000/svg">
    <path d="M230 100 L260 70 L290 100 L320 60 L340 100 L370 40" fill="none" stroke="#1e293b" strokeWidth="12" strokeLinecap="round" strokeLinejoin="round" />
    <path d="M370 40 L370 80 M370 40 L330 40" fill="none" stroke="#1e293b" strokeWidth="12" strokeLinecap="round" strokeLinejoin="round" />
    <text x="50" y="160" fontFamily="Inter, sans-serif" fontWeight="800" fontSize="56" fill="#1e293b">TRENDLINE</text>
  </svg>
);
