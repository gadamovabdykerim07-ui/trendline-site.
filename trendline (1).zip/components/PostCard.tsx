
import React from 'react';
import { Post } from '../types';
import { FileText, Video, ImageIcon, User, Calendar, Download } from 'lucide-react';

interface PostCardProps {
  post: Post;
  isAdmin?: boolean;
  onDelete?: (id: string) => void;
}

export const PostCard: React.FC<PostCardProps> = ({ post, isAdmin, onDelete }) => {
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden hover:shadow-md transition-shadow duration-300 flex flex-col h-full">
      <div className="relative aspect-video bg-slate-100 overflow-hidden">
        {post.type === 'photo' && (
          <img 
            src={post.contentUrl} 
            alt={post.title} 
            className="w-full h-full object-cover"
          />
        )}
        {post.type === 'video' && (
          <div className="relative group w-full h-full">
            <video 
              className="w-full h-full object-cover"
              src={post.contentUrl}
              controls={false}
              muted
              loop
              onMouseOver={(e) => e.currentTarget.play()}
              onMouseOut={(e) => e.currentTarget.pause()}
            />
            <div className="absolute inset-0 flex items-center justify-center bg-black/20 pointer-events-none group-hover:bg-transparent transition-all">
              <Video className="text-white w-12 h-12 drop-shadow-lg" />
            </div>
          </div>
        )}
        {post.type === 'document' && (
          <div className="w-full h-full flex flex-col items-center justify-center bg-slate-50 text-slate-400">
            <FileText size={64} className="mb-2" />
            <span className="text-xs font-mono">{post.fileName}</span>
          </div>
        )}
        <div className="absolute top-4 left-4">
          <span className="bg-white/90 backdrop-blur px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider text-slate-800 shadow-sm border border-slate-200">
            {post.category}
          </span>
        </div>
      </div>

      <div className="p-6 flex-grow flex flex-col">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center text-xs text-slate-500 space-x-3">
            <span className="flex items-center space-x-1">
              <User size={12} />
              <span>{post.author}</span>
            </span>
            <span className="flex items-center space-x-1">
              <Calendar size={12} />
              <span>{formatDate(post.createdAt)}</span>
            </span>
          </div>
        </div>

        <h3 className="text-xl font-bold text-slate-900 mb-2 leading-tight">
          {post.title}
        </h3>
        
        <p className="text-slate-600 text-sm leading-relaxed mb-6 line-clamp-3">
          {post.description}
        </p>

        <div className="mt-auto flex items-center justify-between pt-4 border-t border-slate-50">
          {post.type === 'document' ? (
            <a 
              href={post.contentUrl} 
              download={post.fileName}
              className="flex items-center space-x-2 text-sm font-semibold text-blue-600 hover:text-blue-700 transition-colors"
            >
              <Download size={16} />
              <span>Download File</span>
            </a>
          ) : (
             <span className="text-xs font-medium text-slate-400 flex items-center space-x-1">
               {post.type === 'photo' ? <ImageIcon size={14} /> : <Video size={14} />}
               <span className="capitalize">{post.type}</span>
             </span>
          )}

          {isAdmin && onDelete && (
            <button 
              onClick={() => onDelete(post.id)}
              className="text-xs font-bold text-red-500 hover:text-red-700 transition-colors uppercase tracking-widest"
            >
              Delete
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
